# NetCalc Scientific CAS

Production source for a FastAPI + SymPy high-precision CAS PWA.

## Backend

```bash
appdeploy env init --stack=python-fastapi
appdeploy pip install sympy pydantic uvicorn
uvicorn main:app --host 0.0.0.0 --port 8000
```

The ChatGPT AppDeploy integration used for this build does not expose an interactive AppDeploy console, so the first two commands could not be executed from this session.
