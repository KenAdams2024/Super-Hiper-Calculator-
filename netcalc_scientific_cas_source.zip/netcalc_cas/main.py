from __future__ import annotations

import sympy as sp
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from sympy.parsing.sympy_parser import (
    convert_xor,
    implicit_multiplication_application,
    parse_expr,
    standard_transformations,
)

app = FastAPI(title="NetCalc Scientific CAS API", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

TRANSFORMATIONS = standard_transformations + (
    implicit_multiplication_application,
    convert_xor,
)

SAFE_GLOBALS = {
    "Symbol": sp.Symbol,
    "Integer": sp.Integer,
    "Float": sp.Float,
    "Rational": sp.Rational,
    "pi": sp.pi,
    "E": sp.E,
    "I": sp.I,
    "oo": sp.oo,
    "sin": sp.sin,
    "cos": sp.cos,
    "tan": sp.tan,
    "asin": sp.asin,
    "acos": sp.acos,
    "atan": sp.atan,
    "sinh": sp.sinh,
    "cosh": sp.cosh,
    "tanh": sp.tanh,
    "sqrt": sp.sqrt,
    "log": sp.log,
    "ln": sp.log,
    "exp": sp.exp,
    "Abs": sp.Abs,
    "factorial": sp.factorial,
    "gamma": sp.gamma,
}


class ComputeRequest(BaseModel):
    expression: str = Field(min_length=1, max_length=4000)
    precision: int = Field(default=50, ge=1, le=500)


class ComputeResponse(BaseModel):
    input: str
    exact: str
    latex: str
    numerical: str
    precision: int
    free_symbols: list[str]


def parse_expression(source: str) -> sp.Expr:
    source = source.strip()
    if not source:
        raise ValueError("Expression is empty.")
    return sp.simplify(
        parse_expr(
            source,
            local_dict=SAFE_GLOBALS,
            global_dict={"__builtins__": {}},
            transformations=TRANSFORMATIONS,
            evaluate=True,
        )
    )


def high_precision_string(expr: sp.Expr, precision: int) -> str:
    return sp.sstr(sp.N(expr, precision), full_prec=True)


@app.get("/api/health")
def health() -> dict[str, str]:
    return {"status": "ok", "engine": "sympy", "max_precision": "500"}


@app.post("/api/compute", response_model=ComputeResponse)
def compute(request: ComputeRequest) -> ComputeResponse:
    try:
        expr = parse_expression(request.expression)
        return ComputeResponse(
            input=request.expression,
            exact=sp.sstr(expr),
            latex=sp.latex(expr),
            numerical=high_precision_string(expr, request.precision),
            precision=request.precision,
            free_symbols=sorted(str(symbol) for symbol in expr.free_symbols),
        )
    except (SyntaxError, TypeError, ValueError, ZeroDivisionError, sp.SympifyError) as exc:
        raise HTTPException(status_code=400, detail=f"Invalid expression: {exc}") from exc
    except Exception as exc:
        raise HTTPException(status_code=422, detail=f"Could not compute expression: {exc}") from exc


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)
